import java.util.List;

import org.hibernate.query.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mtc.app.entity.Product;
import com.mtc.app.entity.Supplier;
import com.mtc.app.util.HibernateUtil;

public class TestJoin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		SessionFactory s=HibernateUtil.getSessionFactory();
		Session session=s.openSession();
		Query <Object[]> q=session.createQuery("select p,s from  Product p inner join p. supplier ");
		List<Object[]> a=q.list();
		for(Object[] o: a)
		{
			Product p=(Product)o[0];
			Supplier su=(Supplier)o[1];
			System.out.println(p);
			System.out.println(su);
			System.out.println();
			session.close();
			s.close();
			
		}
	}

}
