import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class TestFetching {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory s=HibernateUtil.getSessionFactory();
		
		Session session=s.openSession();
		Product p=new Product("rex", "dog", 100);
		//Product p=session.get(Product.class, 1);---fetching records
		//System.out.println("Id  :" +p.getId());
		//System.out.println("Name  :" +p.getName());
		//System.out.println("Price  :" +p.getPrice());
		session.close();
		s.close();
		
		
	}

}
