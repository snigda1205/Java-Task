import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.mtc.app.entity.Product;
import com.mtc.app.util.HibernateUtil;

public class TestCriteria {

	private static final String Query = null;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SessionFactory s=HibernateUtil.getSessionFactory();
		Session session=s.openSession();
		CriteriaBuilder c=s.getCriteriaBuilder();
		CriteriaQuery<Product> p=c.createQuery(Product.class);
Root<Product> root= p.from(Product.class);
p.select(root).where(c.gt(root.<Integer>get("id"), 1));
org.hibernate.query.Query<Product> query=session.createQuery(p);
List<Product> pro=query.list();
pro.stream().forEach(System.out::println);
s.close();
session.close();

	}

}
