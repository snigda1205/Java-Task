import { Component, OnInit } from '@angular/core';
import * as firebase from 'firebase';
import { AngularFireAuth } from 'angularfire2/auth';
import { Observable } from 'rxjs';

@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(public authVariable: AngularFireAuth) { }

  ngOnInit() {
  }

  displayName = "Login in to display your name!!!";
  user$: Observable<firebase.User>;

  login() {
    this.authVariable.auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
    this.user$ = this.authVariable.authState;
    console.log(this.user$);
  }

  logout() {
    this.authVariable.auth.signOut();
  }
}
