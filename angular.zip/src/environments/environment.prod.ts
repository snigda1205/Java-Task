export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCrdo4Ev0E3pLtEj6EWRPSAZdF6Qr7V8P0",
    authDomain: "demoproject-fc097.firebaseapp.com",
    databaseURL: "https://demoproject-fc097.firebaseio.com",
    projectId: "demoproject-fc097",
    storageBucket: "demoproject-fc097.appspot.com",
    messagingSenderId: "188599309914"
  }
};
