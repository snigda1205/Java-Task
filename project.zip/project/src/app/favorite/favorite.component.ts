import { Component, OnInit, Input,Output,EventEmitter } from '@angular/core';

@Component({
  selector: 'app-favorite',
  templateUrl: './favorite.component.html',
  styleUrls: ['./favorite.component.css']
})
export class FavoriteComponent implements OnInit {

  constructor() {
    this.isFavorite = true;
   }

  ngOnInit() {
  }

  @Input() isFavorite: boolean;
  onStarClicked(){
    this.isFavorite = !this.isFavorite;
    this.change.emit(this.isFavorite);
  }

  @Output() change = new EventEmitter();
}
