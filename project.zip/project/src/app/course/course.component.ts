import { Component, OnInit, Input } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})

export class CourseComponent implements OnInit {

  constructor(public service: DataService) {

  }

  course = {
    currentDate: new Date(2018, 5, 5),
    currency: 143.32,
    rating: 43.2334,
    inputString: 'northwest missouri state university',
    inputNumber: 10
  };

  populate() {
    this.courses = this.service.getCourses();
  }

  update() {
    this.courses.pop();
  }

  courses;
  imageURL = 'https://avatars3.githubusercontent.com/u/25126117?s=460&v=4';
  imageHeight = '100px';

  ngOnInit() {
  }

  eventData = 'nothing entered';
  twoWayTest = 'initial value';
  count = 1;
  onKeyUp(info) {
    this.eventData = info + ' and Enter Pressed ' + (this.count++);
  }

  onTwoWatKeyUp() {
    this.eventData = this.twoWayTest + ' and Enter Pressed ';
  }

  outputDemo = 'not changed';
  onFavoriteChanged(status) {
    this.outputDemo = status ? 'changed' : 'not changed';
  }
}
