import { Component, OnInit, Injectable } from '@angular/core';
import {FormsModule,FormGroup,FormBuilder,Validators} from '@angular/forms';
import{Http, Response,Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import {SpringService} from './../spring.service';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})

export class RegisterComponent implements OnInit {
 
  private url1 = "http://localhost:8080/postAnswer";
  post2;
 
  tempResult = new answerClass();
  onSubmit(form: any): void {  
 
 
    console.log('you submitted value:', form);
    const headers = new Headers({ 'Content-Type': 'application/json' });
this.tempResult.fname=  form.fname;
this.tempResult.lname = form.lname;


this.tempResult.dob = form.date;
this.tempResult.appointmentTime = form.aTime;
    this.post2 = JSON.stringify(this.tempResult);
   
  
    
      this.http.post(this.url1, this.post2, { headers: headers })
      .subscribe(response => {
        console.log(response.json());
      });
      this.s1.getConfirmation().subscribe(Response => {
        this.title1 = Response.json();
       this.confirmationNumber = this.title1.number;
      })
   }
   public ngOnInit(): void {
   
}
  title; title1;
  fname;
  lname; confirmationNumber=0;
  constructor(private s1: SpringService, private http: Http,  private formBuilder: FormBuilder,) {
    s1.getStudent().subscribe(Response => {
      this.title = Response.json();
    this.fname = this.title.firstName;
    this.lname=this.title.lastName;
   
    })
    this.s1.getConfirmation().subscribe(Response => {
      this.title1 = Response.json();
     this.confirmationNumber = this.title1.number;
    })
   
 }

}
export class answerClass {
  fname: String
  lname: String
 dob: Date
 appointmentTime: Date
  constructor() {
  }
}