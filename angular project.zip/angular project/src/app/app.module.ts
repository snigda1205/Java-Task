import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Component } from '@angular/core';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { HttpClientModule} from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './login/login.component';

import {FormsModule,FormGroup,ReactiveFormsModule} from '@angular/forms';
import {FileUploadModule} from 'primeng/primeng';

import {
  SocialLoginModule,
  AuthServiceConfig,
  GoogleLoginProvider,
  FacebookLoginProvider,
  
} from 'angular5-social-login';



import { RegisterComponent } from './register/register.component';

import { SubmitComponent } from './submit/submit.component';

import { NumberComponent } from './number/number.component';
export function getAuthServiceConfigs() {
  const config = new AuthServiceConfig(
    [{
      id: FacebookLoginProvider.PROVIDER_ID,
      provider: new FacebookLoginProvider('2070774416285250')
    },
      {
        id: GoogleLoginProvider.PROVIDER_ID,
        provider: new GoogleLoginProvider('50573442860-6lf1eme9lnsjra8vl8mil36qn2ecm959.apps.googleusercontent.com')
      },
    ]
  );
  return config;
}

const appRoutes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'login/id', component: LoginComponent },
  { path: 'home', component: HomeComponent },
 

  { path: 'register', component: RegisterComponent },

  
 
  { path: 'submit', component: SubmitComponent },
  { path: 'number', component: NumberComponent },
 
  { path: '',
    redirectTo: '/login',
    pathMatch: 'full'
  }
];

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
   
    SubmitComponent, 
  
  
 
   
    NumberComponent,

   
],
  imports: [
    BrowserModule,
    SocialLoginModule,
    HttpClientModule,
    HttpModule,
    FormsModule,
    ReactiveFormsModule,
   FileUploadModule,
    RouterModule.forRoot(
      appRoutes)
      
  ],
  providers: [
    {
      provide: AuthServiceConfig,
      useFactory: getAuthServiceConfigs
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
