import { Injectable } from '@angular/core';
import { Http } from '@angular/http';

@Injectable({
  providedIn: 'root'
})
export class SpringService {
  constructor(private http: Http) {

  }
  getStudent() {
    return this.http.get('http://localhost:8080/abc');
  }
  getConfirmation() {
    return this.http.get('http://localhost:8080/abc1');
  }
  getDetails() {
    return this.http.get('http://localhost:8080/postDetails');
  }
  getPatientDetails(){
    return this.http.get('http://localhost:8080/getPatientDetails');
  }
}
