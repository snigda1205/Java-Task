import { Component, OnInit } from '@angular/core';
import {FormsModule} from '@angular/forms';
import{Http, Response,Headers} from '@angular/http';
import 'rxjs/add/operator/map';
import {SpringService} from './../spring.service';

@Component({
  selector: 'app-number',
  templateUrl: './number.component.html',
  styleUrls: ['./number.component.css']
})
export class NumberComponent {
  private url1 = "http://localhost:8080/postAnswer";
  private url2="http://localhost:8080/abc";
  post2;
 
  tempResult = new answerClass();
  title; title1;
  fname;
  lname; confirmationNumber=0;
  
  constructor(private s1: SpringService, private http: Http) {
    s1.getStudent().subscribe(Response => {
      this.title = Response.json();
    this.fname = this.title.firstName;
    this.lname=this.title.lastName;
   
    })
    this.s1.getConfirmation().subscribe(Response => {
      this.title1 = Response.json();
     this.confirmationNumber = this.title1.number;
    })
    

  
  
}
}
  export class answerClass {
    fname: String
    lname: String
   dob: Date
   appointmentTime: Date
    constructor() {
    }

}
