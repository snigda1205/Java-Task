import { AutheticationProfileServiceService } from './AutheticationProfileService.service';
import { Component, OnInit} from '@angular/core';
import {SpringService} from './spring.service';
import {Http} from '@angular/http';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  title;
  fname;
  lname;
  constructor(private s1: SpringService, private http: Http) {
    s1.getStudent().subscribe(Response => {
      this.title = Response.json();
    this.fname = this.title.firstName;
    this.lname=this.title.lastName;
    })
   
}}



