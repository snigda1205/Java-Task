
import { Component, OnInit} from '@angular/core';
import {SpringService} from './../spring.service';
import { Observable } from 'rxjs/Observable';
import {
  AuthService,
  FacebookLoginProvider,
  GoogleLoginProvider
} from 'angular5-social-login';
import { DOCUMENT } from '@angular/common';
import { Router } from '@angular/router';
import{Http, Response,Headers} from '@angular/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent  {
  private url1 = "http://localhost:8080/postConfirmationNumber";
 
  post2;
 
  tempResult = new sendId();
  title; title1;
  fname;
  dob ;
  appointment ;
  lname; confirmationNumber=0;
  onSubmit(form: any): void {  

    console.log('you submitted value:', form);
    const headers = new Headers({ 'Content-Type': 'application/json' });
this.tempResult.number=  form.num;
    this.post2 = JSON.stringify(this.tempResult);
      this.http.post(this.url1, this.post2, { headers: headers })
      .subscribe(response => {
        console.log(response.json());
      });
      this.s1.getPatientDetails().subscribe(Response => {
        this.title1 = Response.json();
       this.fname = this.title1.fname;
       this.lname=this.title1.lname;
       this.dob=this.title1.dob;
       this.appointment=this.title1.appointmentTime;
      })
   }
 

  
  constructor(private s1: SpringService, private http: Http) {

}
  
  
}
export class sendId {
  number: String
  constructor() {
  }
}



