import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payrollnav',
  templateUrl: './payrollnav.component.html',
  styleUrls: ['./payrollnav.component.css']
})
export class PayrollnavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
