import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DatasharedService {
datafromLogin: any;
constructor() { }

}
