
public class SavingsAccount {
	
	int accountNo;
	private float balance;
	String status;
	private int pin;
	String branch;
	final static float interestRate=3.25f;
	//default cons
	public SavingsAccount()
	{
		
	}
	public float getBalance() {
		return balance;
	}

	public void setBalance(float balance) {
		this.balance = balance;
	}
	public void isPinValid(int pin)
	{
		if(this.pin==pin)
		{
			System.out.println("correct pin");
		}
		else
		{
			System.out.println("error");
		}
	}

	//parameterized constructor 
	public SavingsAccount(int accountNo, float balance, String status, int pin, String branch) {
		super();
		this.accountNo = accountNo;
		this.balance = balance;
		this.status = status;
		this.pin = pin;
		this.branch = branch;
	}
	//instance method or non static method
	//withdraw(int)
	public void withdraw(int withdrawAmount)
	{
		if(this.status.equals("active")) {
		if(withdrawAmount <= this.balance )
			this.balance=this.balance- withdrawAmount;
			else
			{
				System.out.println("no funds");
			}
		}
		else
		{
			System.out.println("inactive");
		}
			
	}
	//withdraw(int,int)
	public void withdraw(int pin,int withdrawAmount)
	{
		if(this.pin==pin)
		{
			if(withdrawAmount>4000)
			{
				 System.out.println("exceeded");
			}
			else {
				withdraw(withdrawAmount);
			}
		}
		else
		{
			System.out.println("invalid pin");
		}
	}
	public void deposit(int depositAmount)
	{
		if(depositAmount>0)
		{
			this.balance=this.balance+depositAmount;
		}
		else
		{
			System.out.println("error");
		}
	}
	

}
