
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			SavingsAccount a=new SavingsAccount(1,2,"active",22,"aa");
		
		a=null;
		a.withdraw(100);
		System.out.println("account no" +a.accountNo);
		
		}
		catch (ArithmeticException e) {
			e.printStackTrace();
		}
		catch(NullPointerException e)
		{
			e.printStackTrace();
		}
		
		
    System.out.println("hi");
	}

}
