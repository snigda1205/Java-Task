package com.example.demo;

import java.util.Date;

public class AnswerFromClinet {
	private String fname, lname;
	private String dob, appointmentTime;

	public AnswerFromClinet(String fname, String lname, String dob, String appointmentTime) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
		this.appointmentTime = appointmentTime;
	}

	

	public String getAppointmentTime() {
		return appointmentTime;
	}

	public void setAppointmentTime(String appointmentTime) {
		this.appointmentTime = appointmentTime;
	}

	public AnswerFromClinet()
	{
		
	}
	
	public AnswerFromClinet(String fname, String lname) {
		super();
		this.fname = fname;
		this.lname = lname;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public AnswerFromClinet(String fname, String lname, String dob) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.dob = dob;
	}
	

	
	
}
