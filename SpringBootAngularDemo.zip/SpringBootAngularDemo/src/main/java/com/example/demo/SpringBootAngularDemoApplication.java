package com.example.demo;

import java.util.Date;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@SpringBootApplication
@RestController
public class SpringBootAngularDemoApplication {
private static ArrayList<AnswerFromClinet> clinetList = new ArrayList<AnswerFromClinet>();
private static ConfirmationNumber cNumber = new ConfirmationNumber();
	public static void main(String[] args) {
		SpringApplication.run(SpringBootAngularDemoApplication.class, args);
	
	}
	@RequestMapping("/abc")
	public Patient main1() throws SQLException, ClassNotFoundException {
	
		Class c1 = Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/sys?autoReconnect=true&useSSL=false";
		String username = "snigda";
		String password = "123456789";
		Connection conn1 = DriverManager.getConnection(dbURL, username, password);
		 Statement stmt = conn1.createStatement();
	      ResultSet rs1 = stmt.executeQuery("select fname from appointmentlist");
	      Patient p1 = new Patient();
	      while ( rs1.next() ) {
	    	 
                p1.setFirstName(rs1.getString("fname"));
              
	      }
	      conn1.close();
	      return p1;
	}
	@PostMapping("/postAnswer")
	public void main3(@RequestBody AnswerFromClinet s1) throws SQLException, ClassNotFoundException {
		System.out.println("In PostAnswer method");
		System.out.println("First Answer: "+s1.getFname() +" "+s1.getLname() +" Date: "+ s1.getDob()+"Appoint number: "+ s1.getAppointmentTime());
		
		Class c1 = Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/sys?autoReconnect=true&useSSL=false";
		String username = "snigda";
		String password = "123456789";
		Connection conn = DriverManager.getConnection(dbURL, username, password);
		if(conn!=null) {
			System.out.println("Connected to DB");
			 String query = " insert into appointmentlist (fname, lname, dob ,appointment)"
				        + " values (?, ?, ?, ?)";	
			 PreparedStatement preparedStmt = conn.prepareStatement(query);
		      preparedStmt.setString (1, s1.getFname());
		      preparedStmt.setString (2, s1.getLname());
		      preparedStmt.setString  (3, s1.getDob());
		      preparedStmt.setString(4, s1.getAppointmentTime());
		      AnswerFromClinet temp = new AnswerFromClinet(s1.getFname(),s1.getLname(),s1.getDob(),s1.getAppointmentTime());
		      clinetList.add(temp);
		      System.out.println("Inserted ");
		      preparedStmt.execute();
		      conn.close();
		     
		    
		}
		
	}
	
	@RequestMapping("/abc1")
	public ConfirmationNumber main4	() throws ClassNotFoundException, SQLException {
		Class c1 = Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/sys?autoReconnect=true&useSSL=false";
		String username = "snigda";
		String password = "123456789";
		Connection conn1 = DriverManager.getConnection(dbURL, username, password);
		 Statement stmt = conn1.createStatement();
	      ResultSet rs1 = stmt.executeQuery("select id from appointmentlist");
	      ConfirmationNumber cn1 = new ConfirmationNumber();
	      while ( rs1.next() ) {
	    	 
                cn1.setNumber(rs1.getInt("id"));
            
               
           }  
	      conn1.close();
	      return cn1;
	      
		
	}

	@RequestMapping("/postDetails")
	public AnswerFromClinet main5 () throws SQLException, ClassNotFoundException   {
		
		Class c1 = Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/sys?autoReconnect=true&useSSL=false";
		String username = "snigda";
		String password = "123456789";
		Connection conn2 = DriverManager.getConnection(dbURL, username, password);
		Statement stmt = conn2.createStatement();
	      ResultSet rs2 = stmt.executeQuery("select fname from appointmentlist");
	      AnswerFromClinet a1 = new AnswerFromClinet();
	      while ( rs2.next() ) {
	    	 
                a1.setFname(rs2.getString("fname"));
              
              
	      }
          
           conn2.close();
           return a1;
         }  
	
		     
		    
		
@PostMapping("/postConfirmationNumber")
public void main6(@RequestBody ConfirmationNumber s1){
	System.out.println("In PostAnswer method");
	System.out.println("Confirmation Number :"+s1.getNumber());
	
	cNumber.setNumber(s1.getNumber());
	
}
@RequestMapping("/getPatientDetails")
public AnswerFromClinet main7	() throws ClassNotFoundException, SQLException {
	Class c1 = Class.forName("com.mysql.jdbc.Driver");
	String dbURL = "jdbc:mysql://localhost:3306/sys?autoReconnect=true&useSSL=false";
	String username = "snigda";
	String password = "123456789";
	Connection conn1 = DriverManager.getConnection(dbURL, username, password);
	 Statement stmt = conn1.createStatement();
      ResultSet rs1 = stmt.executeQuery("select * from appointmentlist where id = "+cNumber.getNumber());
      AnswerFromClinet cn1 = new AnswerFromClinet();
      while ( rs1.next() ) {
            cn1.setFname(rs1.getString("fname"));
            cn1.setLname(rs1.getString("lname"));
            cn1.setDob(rs1.getString("dob"));
            cn1.setAppointmentTime(rs1.getString("appointment"));
        
           
       }  
      conn1.close();
      return cn1;
      
	
}
}
		

